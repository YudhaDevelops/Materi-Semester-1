#include <stdio.h>
#include <conio.h>

int main(int argc, char** argv)
{
	int baris, kolom, max=4, bil[4][4], temp;

	printf( "\n      Matriks 4x4\n" );
	printf( "-------------------------\n\n");
	
	for( kolom = 0; kolom < max; kolom++ ){
		for( baris = 0; baris < max; baris++ ){
				printf( "Bilangan %d, %d ?: ", kolom, baris );
				scanf( "%d", &bil[kolom][baris]);
			}
		}

	printf("\nMatriks 4x4 : \n");
	for( kolom = 0; kolom < max; kolom++ ){
		for( baris = 0; baris < max; baris++ ){
				printf( "%d ", bil[kolom][baris]);
			}
			printf("\n");
		}

	printf("\nMatriks Segitiga Bawah : \n");
	for( kolom = 0; kolom < max; kolom++ ){
		for( baris = 0; baris < max; baris++ ){
				if(baris <= kolom)
					printf( "%d ", bil[kolom][baris]);
				else
					printf("0 ");
			}
			printf("\n");
		}
		
	printf("\nMatriks Diagonal : \n");
	for( kolom = 0; kolom < max; kolom++ ){
		for( baris = 0; baris < max; baris++ ){
				if(baris == kolom)
					printf( "%d ", bil[kolom][baris]);
				else
					printf("0 ");
			}
			printf("\n");
		}

 	printf( "\n\n-------------------------\n");
	printf( "2020 (c) Agung Hernawan\n\n"); 
    printf( "Tekan Sembarang Tombol untuk Keluar...");
    getch();	

}

