#include <stdio.h>
#include <conio.h>
#include <math.h>

int main(int argc, char** argv)
{
	int baris, kolom, max=0, bil[100];
	double sum=0, rerata, varians=0, stdev = 0, maksimum, minimum;

	printf( "\n        Statistik\n" );
	printf( "-------------------------\n\n");

	do{
		printf("Jumlah bilangan (max 100) ?: ");
		scanf("%d", &max);
	} while(max <= 0 || max > 100);	
	printf("\n");
	
	for(baris = 0; baris < max; baris++){
		printf( "Bilangan ke-%d ?: ", baris );
		scanf( "%d", &bil[baris]);
		} 

	for( kolom = 0; kolom < max; kolom++ ){
			sum += bil[kolom];
		}
	rerata = sum / max;

	for( kolom = 0; kolom < max; kolom++ ){
			varians += (bil[kolom]-rerata) * (bil[kolom]-rerata);
		}
	varians /= (max-1);
	stdev = sqrt(varians);

	maksimum = bil[0];
	minimum = bil[0];
	for( kolom = 1; kolom < max; kolom++ ){
			if(bil[kolom] > maksimum)
				maksimum = bil[kolom];
			if(bil[kolom] < minimum)
				minimum = bil[kolom];
		}
	
	printf("\nSigma Data     : %7.2f\n", sum);
	printf("Rerata         : %7.2f\n", rerata);
	printf("Varians	       : %7.2f\n", varians);
	printf("Standart Dev   : %7.2f\n", stdev);
	printf("Nilai Maksimum : %7.2f\n", maksimum);
	printf("Nilai Minimum  : %7.2f\n", minimum);
	
 	printf( "\n\n-------------------------\n");
	printf( "2020 (c) Agung Hernawan\n\n"); 
    printf( "Tekan Sembarang Tombol untuk Keluar...");
    getch();	

}

