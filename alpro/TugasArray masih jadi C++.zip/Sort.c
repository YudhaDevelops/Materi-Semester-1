#include <stdio.h>
#include <conio.h>

int main(int argc, char** argv)
{
	int baris, kolom, max=0, bil[100], temp;

	printf( "\n       Bubble Sort\n" );
	printf( "-------------------------\n\n");

	do{
		printf("Jumlah bilangan (max 100) ?: ");
		scanf("%d", &max);
	} while(max <= 0 || max > 100);	
	printf("\n");
	
	for(baris = 0; baris < max; baris++){
		printf( "Bilangan ke-%d ?: ", baris );
		scanf( "%d", &bil[baris]);
		} 

	for( kolom = 0; kolom < max; kolom++ ){
		for( baris = 0; baris+kolom < max-1; baris++ ){
			if(bil[baris] > bil[baris+1]){
				temp = bil[baris];
				bil[baris] = bil[baris+1];
				bil[baris+1] = temp;				
				}
			}
		}

	printf("\nBilangan terurut : ");
	for(baris = 0; baris < max; baris++){
		printf( "%d ", bil[baris] );
		} 
		
 	printf( "\n\n-------------------------\n");
	printf( "2020 (c) Agung Hernawan\n\n"); 
    printf( "Tekan Sembarang Tombol untuk Keluar...");
    getch();	

}

